from .views import lesson_4
from django.urls import  path
urlpatterns = [path('lesson_4',lesson_4)]